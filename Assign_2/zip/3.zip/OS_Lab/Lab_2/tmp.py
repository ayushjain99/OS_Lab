print("Incorrect Syntax, exiting")
print("python3 entropy.py <filename>")
